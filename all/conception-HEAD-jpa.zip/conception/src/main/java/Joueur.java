
import java.util.LinkedList;
import java.util.List;



/**
 * <!-- begin-user-doc -->
 * <!--  end-user-doc  -->
 * @generated
 */
 
@javax.persistence.Entity 
public class Joueur
{
	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	 
	@javax.persistence.Column(nullable = false) 
	protected String pseudo;

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	 
	@javax.persistence.Column(nullable = false) 
	protected String pwd;

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	 
	@javax.persistence.OneToMany(mappedBy = "mj") 
	protected List<Aventure> aventures;

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	 
	@javax.persistence.OneToMany(mappedBy = "mj") 
	protected List<Episode> episodes;

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	 
	@javax.persistence.OneToMany(mappedBy = "transfert") 
	protected List<Personnage> transferts;

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	 
	@javax.persistence.OneToMany(mappedBy = "mj") 
	protected List<Personnage> supervisions;

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	 
	@javax.persistence.OneToMany(mappedBy = "joueur") 
	protected List<Personnage> possessions;

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	 
	@javax.persistence.OneToMany(mappedBy = "validateur") 
	protected List<Personnage> validations;

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	 
	@javax.persistence.OneToMany(mappedBy = "joueur") 
	protected List<Joue> parties;

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	@javax.persistence.Id 
	@javax.persistence.Column(nullable = false) 
	protected final Long id = 0L;

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 */
	public Joueur(){
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void basicRemoveAventures(Aventure oldAventures) {
		if(this.aventures == null)
			return;
		
		while (this.aventures.contains(oldAventures))
			this.aventures.remove(oldAventures);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void basicRemoveEpisodes(Episode oldEpisodes) {
		if(this.episodes == null)
			return;
		
		while (this.episodes.contains(oldEpisodes))
			this.episodes.remove(oldEpisodes);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void basicRemoveTransferts(Personnage oldTransferts) {
		if(this.transferts == null)
			return;
		
		while (this.transferts.contains(oldTransferts))
			this.transferts.remove(oldTransferts);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void basicRemoveSupervisions(Personnage oldSupervisions) {
		if(this.supervisions == null)
			return;
		
		while (this.supervisions.contains(oldSupervisions))
			this.supervisions.remove(oldSupervisions);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void basicRemovePossessions(Personnage oldPossessions) {
		if(this.possessions == null)
			return;
		
		while (this.possessions.contains(oldPossessions))
			this.possessions.remove(oldPossessions);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void basicRemoveValidations(Personnage oldValidations) {
		if(this.validations == null)
			return;
		
		while (this.validations.contains(oldValidations))
			this.validations.remove(oldValidations);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void basicRemoveParties(Joue oldParties) {
		if(this.parties == null)
			return;
		
		while (this.parties.contains(oldParties))
			this.parties.remove(oldParties);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void basicAddAventures(Aventure newAventures) {
		if(this.aventures == null) {
			this.aventures = new LinkedList<Aventure>();
		}
		
		this.aventures.add(newAventures);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void basicAddEpisodes(Episode newEpisodes) {
		if(this.episodes == null) {
			this.episodes = new LinkedList<Episode>();
		}
		
		this.episodes.add(newEpisodes);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void basicAddTransferts(Personnage newTransferts) {
		if(this.transferts == null) {
			this.transferts = new LinkedList<Personnage>();
		}
		
		this.transferts.add(newTransferts);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void basicAddSupervisions(Personnage newSupervisions) {
		if(this.supervisions == null) {
			this.supervisions = new LinkedList<Personnage>();
		}
		
		this.supervisions.add(newSupervisions);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void basicAddPossessions(Personnage newPossessions) {
		if(this.possessions == null) {
			this.possessions = new LinkedList<Personnage>();
		}
		
		this.possessions.add(newPossessions);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void basicAddValidations(Personnage newValidations) {
		if(this.validations == null) {
			this.validations = new LinkedList<Personnage>();
		}
		
		this.validations.add(newValidations);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void basicAddParties(Joue newParties) {
		if(this.parties == null) {
			this.parties = new LinkedList<Joue>();
		}
		
		this.parties.add(newParties);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	private String getPseudo() {
		return this.pseudo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	private String getPwd() {
		return this.pwd;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public List<Aventure> getAventures() {
		if(this.aventures == null) {
				this.aventures = new LinkedList<Aventure>();
		}
		return (List<Aventure>) this.aventures;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public List<Episode> getEpisodes() {
		if(this.episodes == null) {
				this.episodes = new LinkedList<Episode>();
		}
		return (List<Episode>) this.episodes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public List<Personnage> getTransferts() {
		if(this.transferts == null) {
				this.transferts = new LinkedList<Personnage>();
		}
		return (List<Personnage>) this.transferts;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public List<Personnage> getSupervisions() {
		if(this.supervisions == null) {
				this.supervisions = new LinkedList<Personnage>();
		}
		return (List<Personnage>) this.supervisions;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public List<Personnage> getPossessions() {
		if(this.possessions == null) {
				this.possessions = new LinkedList<Personnage>();
		}
		return (List<Personnage>) this.possessions;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public List<Personnage> getValidations() {
		if(this.validations == null) {
				this.validations = new LinkedList<Personnage>();
		}
		return (List<Personnage>) this.validations;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public List<Joue> getParties() {
		if(this.parties == null) {
				this.parties = new LinkedList<Joue>();
		}
		return (List<Joue>) this.parties;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public long getId() {
		return this.id;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void addAllAventures(List<Aventure> newAventures) {
		if (this.aventures == null) {
			this.aventures = new LinkedList<Aventure>();
		}
		for (Aventure tmp : newAventures)
			tmp.setMj(this);
		
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void addAllEpisodes(List<Episode> newEpisodes) {
		if (this.episodes == null) {
			this.episodes = new LinkedList<Episode>();
		}
		for (Episode tmp : newEpisodes)
			tmp.setMj(this);
		
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void addAllTransferts(List<Personnage> newTransferts) {
		if (this.transferts == null) {
			this.transferts = new LinkedList<Personnage>();
		}
		for (Personnage tmp : newTransferts)
			tmp.setTransfert(this);
		
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void addAllSupervisions(List<Personnage> newSupervisions) {
		if (this.supervisions == null) {
			this.supervisions = new LinkedList<Personnage>();
		}
		for (Personnage tmp : newSupervisions)
			tmp.setMj(this);
		
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void addAllPossessions(List<Personnage> newPossessions) {
		if (this.possessions == null) {
			this.possessions = new LinkedList<Personnage>();
		}
		for (Personnage tmp : newPossessions)
			tmp.setJoueur(this);
		
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void addAllValidations(List<Personnage> newValidations) {
		if (this.validations == null) {
			this.validations = new LinkedList<Personnage>();
		}
		for (Personnage tmp : newValidations)
			tmp.setValidateur(this);
		
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void addAllParties(List<Joue> newParties) {
		if (this.parties == null) {
			this.parties = new LinkedList<Joue>();
		}
		for (Joue tmp : newParties)
			tmp.setJoueur(this);
		
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void removeAllAventures(List<Aventure> newAventures) {
		if(this.aventures == null) {
			return;
		}
		
		this.aventures.removeAll(newAventures);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void removeAllEpisodes(List<Episode> newEpisodes) {
		if(this.episodes == null) {
			return;
		}
		
		this.episodes.removeAll(newEpisodes);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void removeAllTransferts(List<Personnage> newTransferts) {
		if(this.transferts == null) {
			return;
		}
		
		this.transferts.removeAll(newTransferts);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void removeAllSupervisions(List<Personnage> newSupervisions) {
		if(this.supervisions == null) {
			return;
		}
		
		this.supervisions.removeAll(newSupervisions);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void removeAllPossessions(List<Personnage> newPossessions) {
		if(this.possessions == null) {
			return;
		}
		
		this.possessions.removeAll(newPossessions);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void removeAllValidations(List<Personnage> newValidations) {
		if(this.validations == null) {
			return;
		}
		
		this.validations.removeAll(newValidations);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void removeAllParties(List<Joue> newParties) {
		if(this.parties == null) {
			return;
		}
		
		this.parties.removeAll(newParties);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	private void setPseudo(String myPseudo) {
		this.pseudo = myPseudo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	private void setPwd(String myPwd) {
		this.pwd = myPwd;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void addAventures(Aventure newAventures) {
		this.basicAddAventures(newAventures);
		newAventures.basicSetMj(this);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void addEpisodes(Episode newEpisodes) {
		this.basicAddEpisodes(newEpisodes);
		newEpisodes.basicSetMj(this);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void addTransferts(Personnage newTransferts) {
		this.basicAddTransferts(newTransferts);
		newTransferts.basicSetTransfert(this);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void addSupervisions(Personnage newSupervisions) {
		this.basicAddSupervisions(newSupervisions);
		newSupervisions.basicSetMj(this);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void addPossessions(Personnage newPossessions) {
		this.basicAddPossessions(newPossessions);
		newPossessions.basicSetJoueur(this);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void addValidations(Personnage newValidations) {
		this.basicAddValidations(newValidations);
		newValidations.basicSetValidateur(this);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void addParties(Joue newParties) {
		this.basicAddParties(newParties);
		newParties.basicSetJoueur(this);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	private void unsetPseudo() {
		this.pseudo = "";
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	private void unsetPwd() {
		this.pwd = "";
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void removeAventures(Aventure oldAventures) {
		this.basicRemoveAventures(oldAventures);
		oldAventures.unsetMj();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void removeEpisodes(Episode oldEpisodes) {
		this.basicRemoveEpisodes(oldEpisodes);
		oldEpisodes.unsetMj();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void removeTransferts(Personnage oldTransferts) {
		this.basicRemoveTransferts(oldTransferts);
		oldTransferts.unsetTransfert();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void removeSupervisions(Personnage oldSupervisions) {
		this.basicRemoveSupervisions(oldSupervisions);
		oldSupervisions.unsetMj();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void removePossessions(Personnage oldPossessions) {
		this.basicRemovePossessions(oldPossessions);
		oldPossessions.unsetJoueur();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void removeValidations(Personnage oldValidations) {
		this.basicRemoveValidations(oldValidations);
		oldValidations.unsetValidateur();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void removeParties(Joue oldParties) {
		this.basicRemoveParties(oldParties);
		oldParties.unsetJoueur();
	}

}

