



/**
 * <!-- begin-user-doc -->
 * <!--  end-user-doc  -->
 * @generated
 */
 
@javax.persistence.Entity 
public class Joue
{
	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	 
	@javax.persistence.ManyToOne 
	@javax.persistence.JoinColumn(nullable = false) 
	protected Aventure aventure;

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	 
	@javax.persistence.ManyToOne 
	@javax.persistence.JoinColumn(nullable = false) 
	protected Personnage personnage;

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	 
	@javax.persistence.ManyToOne 
	@javax.persistence.JoinColumn(nullable = false) 
	protected Joueur joueur;

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	@javax.persistence.Id 
	@javax.persistence.Column(nullable = false) 
	protected final Long id = 0L;

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 */
	public Joue(){
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void basicSetAventure(Aventure myAventure) {
		if (this.aventure != myAventure) {
			if (myAventure != null){
				if (this.aventure != myAventure) {
					Aventure oldaventure = this.aventure;
					this.aventure = myAventure;
					if (oldaventure != null)
						oldaventure.removeParties(this);
				}
			}
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void basicSetPersonnage(Personnage myPersonnage) {
		if (this.personnage != myPersonnage) {
			if (myPersonnage != null){
				if (this.personnage != myPersonnage) {
					Personnage oldpersonnage = this.personnage;
					this.personnage = myPersonnage;
					if (oldpersonnage != null)
						oldpersonnage.removeParties(this);
				}
			}
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void basicSetJoueur(Joueur myJoueur) {
		if (this.joueur != myJoueur) {
			if (myJoueur != null){
				if (this.joueur != myJoueur) {
					Joueur oldjoueur = this.joueur;
					this.joueur = myJoueur;
					if (oldjoueur != null)
						oldjoueur.removeParties(this);
				}
			}
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public Aventure getAventure() {
		return this.aventure;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public Personnage getPersonnage() {
		return this.personnage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public Joueur getJoueur() {
		return this.joueur;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public long getId() {
		return this.id;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void setAventure(Aventure myAventure) {
		this.basicSetAventure(myAventure);
		myAventure.addParties(this);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void setPersonnage(Personnage myPersonnage) {
		this.basicSetPersonnage(myPersonnage);
		myPersonnage.addParties(this);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void setJoueur(Joueur myJoueur) {
		this.basicSetJoueur(myJoueur);
		myJoueur.addParties(this);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void unsetAventure() {
		if (this.aventure == null)
			return;
		Aventure oldaventure = this.aventure;
		this.aventure = null;
		oldaventure.removeParties(this);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void unsetPersonnage() {
		if (this.personnage == null)
			return;
		Personnage oldpersonnage = this.personnage;
		this.personnage = null;
		oldpersonnage.removeParties(this);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void unsetJoueur() {
		if (this.joueur == null)
			return;
		Joueur oldjoueur = this.joueur;
		this.joueur = null;
		oldjoueur.removeParties(this);
	}

}

