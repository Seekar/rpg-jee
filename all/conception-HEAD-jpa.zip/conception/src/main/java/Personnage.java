
import java.util.LinkedList;
import java.util.List;



/**
 * <!-- begin-user-doc -->
 * <!--  end-user-doc  -->
 * @generated
 */
 
@javax.persistence.Entity 
public class Personnage
{
	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	 
	@javax.persistence.Column(nullable = false) 
	protected String nom;

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	 
	@javax.persistence.Column(nullable = false) 
	protected String naissance;

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	 
	@javax.persistence.Column(nullable = false) 
	protected String profession;

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	 
	@javax.persistence.Column 
	protected String portrait;

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	 
	@javax.persistence.Column(nullable = false) 
	protected boolean valide;

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	 
	@javax.persistence.ManyToOne 
	@javax.persistence.JoinColumn(nullable = false) 
	protected Univers univers;

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	 
	@javax.persistence.ManyToOne 
	protected Joueur transfert;

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	 
	@javax.persistence.ManyToOne 
	protected Joueur mj;

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	 
	@javax.persistence.ManyToOne 
	@javax.persistence.JoinColumn(nullable = false) 
	protected Joueur joueur;

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	 
	@javax.persistence.ManyToOne 
	protected Joueur validateur;

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	 
	@javax.persistence.OneToMany(mappedBy = "personnage") 
	protected List<Joue> parties;

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	 
	@javax.persistence.OneToOne(cascade = javax.persistence.CascadeType.ALL) 
	protected Biographie biographie;

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	@javax.persistence.Id 
	@javax.persistence.Column(nullable = false) 
	protected final Long id = 0L;

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 */
	public Personnage(){
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void basicRemoveParties(Joue oldParties) {
		if(this.parties == null)
			return;
		
		while (this.parties.contains(oldParties))
			this.parties.remove(oldParties);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void basicSetUnivers(Univers myUnivers) {
		if (this.univers != myUnivers) {
			if (myUnivers != null){
				if (this.univers != myUnivers) {
					Univers oldunivers = this.univers;
					this.univers = myUnivers;
					if (oldunivers != null)
						oldunivers.removePersonnages(this);
				}
			}
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void basicSetTransfert(Joueur myTransfert) {
		if (this.transfert != myTransfert) {
			if (myTransfert != null){
				if (this.transfert != myTransfert) {
					Joueur oldtransfert = this.transfert;
					this.transfert = myTransfert;
					if (oldtransfert != null)
						oldtransfert.removeTransferts(this);
				}
			}
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void basicSetMj(Joueur myMj) {
		if (this.mj != myMj) {
			if (myMj != null){
				if (this.mj != myMj) {
					Joueur oldmj = this.mj;
					this.mj = myMj;
					if (oldmj != null)
						oldmj.removeSupervisions(this);
				}
			}
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void basicSetJoueur(Joueur myJoueur) {
		if (this.joueur != myJoueur) {
			if (myJoueur != null){
				if (this.joueur != myJoueur) {
					Joueur oldjoueur = this.joueur;
					this.joueur = myJoueur;
					if (oldjoueur != null)
						oldjoueur.removePossessions(this);
				}
			}
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void basicSetValidateur(Joueur myValidateur) {
		if (this.validateur != myValidateur) {
			if (myValidateur != null){
				if (this.validateur != myValidateur) {
					Joueur oldvalidateur = this.validateur;
					this.validateur = myValidateur;
					if (oldvalidateur != null)
						oldvalidateur.removeValidations(this);
				}
			}
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void basicAddParties(Joue newParties) {
		if(this.parties == null) {
			this.parties = new LinkedList<Joue>();
		}
		
		this.parties.add(newParties);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void basicSetBiographie(Biographie myBiographie) {
		if (this.biographie != myBiographie) {
			if (myBiographie != null){
				if (this.biographie != myBiographie) {
					Biographie oldbiographie = this.biographie;
					this.biographie = myBiographie;
					if (oldbiographie != null)
						oldbiographie.unsetPersonnage();
				}
			}
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	private String getNom() {
		return this.nom;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	private String getNaissance() {
		return this.naissance;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	private String getProfession() {
		return this.profession;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	private String getPortrait() {
		return this.portrait;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	private boolean isValide() {
		return this.valide;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public Univers getUnivers() {
		return this.univers;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public Joueur getTransfert() {
		return this.transfert;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public Joueur getMj() {
		return this.mj;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public Joueur getJoueur() {
		return this.joueur;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public Joueur getValidateur() {
		return this.validateur;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public List<Joue> getParties() {
		if(this.parties == null) {
				this.parties = new LinkedList<Joue>();
		}
		return (List<Joue>) this.parties;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public Biographie getBiographie() {
		return this.biographie;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public long getId() {
		return this.id;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void addAllParties(List<Joue> newParties) {
		if (this.parties == null) {
			this.parties = new LinkedList<Joue>();
		}
		for (Joue tmp : newParties)
			tmp.setPersonnage(this);
		
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void removeAllParties(List<Joue> newParties) {
		if(this.parties == null) {
			return;
		}
		
		this.parties.removeAll(newParties);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	private void setNom(String myNom) {
		this.nom = myNom;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	private void setNaissance(String myNaissance) {
		this.naissance = myNaissance;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	private void setProfession(String myProfession) {
		this.profession = myProfession;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	private void setPortrait(String myPortrait) {
		this.portrait = myPortrait;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	private void setValide(boolean myValide) {
		this.valide = myValide;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void setUnivers(Univers myUnivers) {
		this.basicSetUnivers(myUnivers);
		myUnivers.basicAddPersonnages(this);
		
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void setTransfert(Joueur myTransfert) {
		this.basicSetTransfert(myTransfert);
		myTransfert.basicAddTransferts(this);
		
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void setMj(Joueur myMj) {
		this.basicSetMj(myMj);
		myMj.basicAddSupervisions(this);
		
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void setJoueur(Joueur myJoueur) {
		this.basicSetJoueur(myJoueur);
		myJoueur.basicAddPossessions(this);
		
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void setValidateur(Joueur myValidateur) {
		this.basicSetValidateur(myValidateur);
		myValidateur.basicAddValidations(this);
		
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void addParties(Joue newParties) {
		this.basicAddParties(newParties);
		newParties.basicSetPersonnage(this);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void setBiographie(Biographie myBiographie) {
		this.basicSetBiographie(myBiographie);
		myBiographie.basicSetPersonnage(this);
		
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	private void unsetNom() {
		this.nom = "";
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	private void unsetNaissance() {
		this.naissance = "";
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	private void unsetProfession() {
		this.profession = "";
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	private void unsetPortrait() {
		this.portrait = null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	private void unsetValide() {
		this.valide = false;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void unsetUnivers() {
		if (this.univers == null)
			return;
		Univers oldunivers = this.univers;
		this.univers = null;
		oldunivers.removePersonnages(this);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void unsetTransfert() {
		if (this.transfert == null)
			return;
		Joueur oldtransfert = this.transfert;
		this.transfert = null;
		oldtransfert.removeTransferts(this);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void unsetMj() {
		if (this.mj == null)
			return;
		Joueur oldmj = this.mj;
		this.mj = null;
		oldmj.removeSupervisions(this);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void unsetJoueur() {
		if (this.joueur == null)
			return;
		Joueur oldjoueur = this.joueur;
		this.joueur = null;
		oldjoueur.removePossessions(this);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void unsetValidateur() {
		if (this.validateur == null)
			return;
		Joueur oldvalidateur = this.validateur;
		this.validateur = null;
		oldvalidateur.removeValidations(this);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void removeParties(Joue oldParties) {
		this.basicRemoveParties(oldParties);
		oldParties.unsetPersonnage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void unsetBiographie() {
		if (this.biographie == null)
			return;
		Biographie oldbiographie = this.biographie;
		this.biographie = null;
		oldbiographie.unsetPersonnage();
	}

}

