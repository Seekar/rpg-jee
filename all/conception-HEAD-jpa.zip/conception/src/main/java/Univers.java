
import java.util.LinkedList;
import java.util.List;



/**
 * <!-- begin-user-doc -->
 * <!--  end-user-doc  -->
 * @generated
 */
 
@javax.persistence.Entity 
public class Univers
{
	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	 
	@javax.persistence.Column(nullable = false) 
	protected String nom;

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	 
	@javax.persistence.OneToMany(mappedBy = "univers") 
	protected List<Aventure> aventures;

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	 
	@javax.persistence.OneToMany(mappedBy = "univers") 
	protected List<Personnage> personnages;

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	@javax.persistence.Id 
	@javax.persistence.Column(nullable = false) 
	protected final Long id = 0L;

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 */
	public Univers(){
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void basicRemoveAventures(Aventure oldAventures) {
		if(this.aventures == null)
			return;
		
		while (this.aventures.contains(oldAventures))
			this.aventures.remove(oldAventures);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void basicRemovePersonnages(Personnage oldPersonnages) {
		if(this.personnages == null)
			return;
		
		while (this.personnages.contains(oldPersonnages))
			this.personnages.remove(oldPersonnages);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void basicAddAventures(Aventure newAventures) {
		if(this.aventures == null) {
			this.aventures = new LinkedList<Aventure>();
		}
		
		this.aventures.add(newAventures);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void basicAddPersonnages(Personnage newPersonnages) {
		if(this.personnages == null) {
			this.personnages = new LinkedList<Personnage>();
		}
		
		this.personnages.add(newPersonnages);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	private String getNom() {
		return this.nom;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public List<Aventure> getAventures() {
		if(this.aventures == null) {
				this.aventures = new LinkedList<Aventure>();
		}
		return (List<Aventure>) this.aventures;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public List<Personnage> getPersonnages() {
		if(this.personnages == null) {
				this.personnages = new LinkedList<Personnage>();
		}
		return (List<Personnage>) this.personnages;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public long getId() {
		return this.id;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void addAllAventures(List<Aventure> newAventures) {
		if (this.aventures == null) {
			this.aventures = new LinkedList<Aventure>();
		}
		for (Aventure tmp : newAventures)
			tmp.setUnivers(this);
		
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void addAllPersonnages(List<Personnage> newPersonnages) {
		if (this.personnages == null) {
			this.personnages = new LinkedList<Personnage>();
		}
		for (Personnage tmp : newPersonnages)
			tmp.setUnivers(this);
		
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void removeAllAventures(List<Aventure> newAventures) {
		if(this.aventures == null) {
			return;
		}
		
		this.aventures.removeAll(newAventures);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void removeAllPersonnages(List<Personnage> newPersonnages) {
		if(this.personnages == null) {
			return;
		}
		
		this.personnages.removeAll(newPersonnages);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	private void setNom(String myNom) {
		this.nom = myNom;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void addAventures(Aventure newAventures) {
		this.basicAddAventures(newAventures);
		newAventures.basicSetUnivers(this);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void addPersonnages(Personnage newPersonnages) {
		this.basicAddPersonnages(newPersonnages);
		newPersonnages.basicSetUnivers(this);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	private void unsetNom() {
		this.nom = "";
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void removeAventures(Aventure oldAventures) {
		this.basicRemoveAventures(oldAventures);
		oldAventures.unsetUnivers();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void removePersonnages(Personnage oldPersonnages) {
		this.basicRemovePersonnages(oldPersonnages);
		oldPersonnages.unsetUnivers();
	}

}

